var car, wall; 

function setup() {
  createCanvas(400, 400);
  car = createSprite (390, 200, 20, 20); 
  car.shapeColor = "green"; 
  car.debug = true; 

  wall = createSprite (10, 200, 20, 40); 
  wall.debug = true; 
}

function draw() {
  background(220);
 
  car.velocityX = 10; 
  
  if (car.x - wall.x < car.width/2 + wall.width/2
      && car.x - wall.x < car.width/2 + movingRect.width/2 
      && movingRect.y - fixedRect.y < fixedRect.height/2 + movingRect.height/2
      && fixedRect.y - movingRect.y < fixedRect.height/2 + movingRect.height/2){
  movingRect.shapeColor = "red"; 
  fixedRect.shapeColor = "red"; 
 }
 else { 
   movingRect.shapeColor = "green"; 
   fixedRect.shapeColor = "green";
 }
  
  drawSprites ();  
}